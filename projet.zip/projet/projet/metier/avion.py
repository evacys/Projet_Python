'''
Created on 6 avr. 2016

@author: eva
'''

class Avion(object):
    def __init__(self,id,capaciteMax,autonoMax):
        """ 
        Constructeur de la classe Avion
        """
        self.id = id
        self.capacite = capaciteMax # Nombre de passagers que peut acceuillir l'avion
        self.autono = autonoMax # autonomie de l'avion en km
        
    def localisation(self,id_avion,date,heure): # la date et l'heure doivent être rentrés en Greenwitch
        """
        Fonction qui permet de savoir ou se trouve l'avion à une date et à une heure donnée
        """
        
        pass

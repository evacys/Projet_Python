'''
Created on 6 avr. 2016

@author: eleve
'''

class Reservation(object):
    def __init__(self,idRes,classe,numVol):
        """
        Constructeur de la classe Reservation
        
        param:
        idRes = identifiant de la réservation
        classe = economique ou affaire
        numVol = numéro du vol
        """
        self.idRes = idRes
        self.classe = classe
        self.numVol = numVol

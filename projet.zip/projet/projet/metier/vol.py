'''
Created on 6 avr. 2016

@author: eleve
'''

from aeroport import * 

class Vol(object):
    def __init__(self,numero,aeroDep,aeroArr,heureDep,heureArr):
        """
        Constructeur de la classe Vol
        
        param:
        aeroDep = aeroport de depart
        aeroArr = aeroport d'arrivee
        heureDep = heure de depart
        heureArr = heure d'arrivee
        """
        self.num = numero
        self.aeroDep = aeroDep
        self.aeroArr = aeroArr
        self.heureDep = heureDep
        self.heureArr = heureArr
    
    @property
    def distance(self):
        lat1 = self.aeroDep.lat
        long1 = self.aeroDep.long
        lat2 = self.aeroArr.lat
        long2 = self.aeroArr.long
        ...
    
    @property
    def duree(self):
        pass
    
    def nbPassager(self):
        pass

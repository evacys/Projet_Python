'''
Created on 6 avr. 2016

@author: eleve
'''

class Compagnie(object):
    def __init__(self,nom):
        """
        Constructeur de la classe Compagnie
        """
        self.nom = nom
        
    def attribAvion(self, numVol): # Fonction qui permet de déterminer l'avion effectuant le vol affecté à numVol
        pass

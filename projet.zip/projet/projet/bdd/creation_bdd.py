# -*- coding: utf-8 -*-
"""
Spyder Editor

This is a temporary script file.
"""

from acces_bdd import executer_requete, ouvrir_connexion

def creer_bdd(chemin):
   
   #creation de la connexion
    (base,curseur)=ouvrir_connexion(chemin)
   
   # Création des tables
    executer_requete(curseur, """create table Aeroport (id text primary key, nom text, coordonnees_nord float, coordonnees_est float)""")
    executer_requete(curseur, """create table Ville (id text primary key, nom text, pays text, decalage_fuseau_horaire float)""")
    executer_requete(curseur, """create table Compagnie (id text primary key, nom text)""")
    executer_requete(curseur, """create table Avion (id text primary key, capacite_maximale integer, autonomie_maximale float)""")
    executer_requete(curseur, """create table Vol (numero_de_vol text primary key, id_aeroport_depart text, id_aeroport_arrivee text, date_depart date)""")
    executer_requete(curseur, """create table Passager (id_reservation text, adresse_mail text, nom text, prenom text)""")
   
   
   
   # Ajout des aéroports
    executer_requete(curseur, """insert into Aeroport (id, nom, coordonnees_nord, coordonnees_est) values ("CDG", "Roissy-Charles-de-Gaulle", 49.003652, 2.570892)""")
    executer_requete(curseur, """insert into Aeroport (id, nom, coordonnees_nord, coordonnees_est) values ("BCN", "El Prat", 41.296944, 2.078333)""") 
    executer_requete(curseur, """insert into Aeroport (id, nom, coordonnees_nord, coordonnees_est) values ("AMS", "Schiphol", 52.308059, 4.760857)""")
    executer_requete(curseur, """insert into Aeroport (id, nom, coordonnees_nord, coordonnees_est) values ("LGW", "Gatwick", 51.148152, -019033)""")
    executer_requete(curseur, """insert into Aeroport (id, nom, coordonnees_nord, coordonnees_est) values ("JFK", "John F. Kennedy", 40.640498, -73.778858)""")
    executer_requete(curseur, """insert into Aeroport (id, nom, coordonnees_nord, coordonnees_est) values ("RUN", "Rolland-Garros", -20.890089, 55.516448)""")
    executer_requete(curseur, """insert into Aeroport (id, nom, coordonnees_nord, coordonnees_est) values ("CCS", "Maiquetia-Simon Bolivar", 10.607969, -66.990509)""")
    executer_requete(curseur, """insert into Aeroport (id, nom, coordonnees_nord, coordonnees_est) values ("ULN", "Gengis-Khan", 47.843056, 106.766389)""")
    executer_requete(curseur, """insert into Aeroport (id, nom, coordonnees_nord, coordonnees_est) values ("AKL", "Aeroport international d'Auckland", -37.007625, 174.791665)""")
    executer_requete(curseur, """insert into Aeroport (id, nom, coordonnees_nord, coordonnees_est) values ("KUL", "Aeroport international de Kuala Lumpur", 2.756161, 101.704388)""")
    executer_requete(curseur, """insert into Aeroport (id, nom, coordonnees_nord, coordonnees_est) values ("DLA", "Aeroport international de Douala", 4.007768, 9.71921)""")
    executer_requete(curseur, """insert into Aeroport (id, nom, coordonnees_nord, coordonnees_est) values ("JRO", "Aeroport international du Kilimandjaro", -3.429461, 37.074394)""")
    executer_requete(curseur, """insert into Aeroport (id, nom, coordonnees_nord, coordonnees_est) values ("JNB", "OR Tambo", 40.640498, -73.778858)""")
    executer_requete(curseur, """insert into Aeroport (id, nom, coordonnees_nord, coordonnees_est) values ("GVA", "Aeroport intrernational de Geneve", 46.236389, 6.107222)""")
    executer_requete(curseur, """insert into Aeroport (id, nom, coordonnees_nord, coordonnees_est) values ("TLS", "Toulouse-Blagnac", 43.635, 1.36778)""")
    executer_requete(curseur, """insert into Aeroport (id, nom, coordonnees_nord, coordonnees_est) values ("LYS", "Lyon-Saint-Exupery", 45.725556, 5.081111)""")
    executer_requete(curseur, """insert into Aeroport (id, nom, coordonnees_nord, coordonnees_est) values ("GIG", "Antonio Carlos Jobim", -22.8077554, -43.249826)""")
    executer_requete(curseur, """insert into Aeroport (id, nom, coordonnees_nord, coordonnees_est) values ("EZE", "Aeroport international d'Ezeiza", -34.821872, -58.535671)""")
    executer_requete(curseur, """insert into Aeroport (id, nom, coordonnees_nord, coordonnees_est) values ("YUL", "Pierre Elliott Trudeau", 45.468649, -73.741389)""")
    executer_requete(curseur, """insert into Aeroport (id, nom, coordonnees_nord, coordonnees_est) values ("ARN", "Arlanda", 59.651944, 17.918611)""")
    executer_requete(curseur, """insert into Aeroport (id, nom, coordonnees_nord, coordonnees_est) values ("TLV", "David Ben Gourion", 32.012079, 34.88657)""")
    executer_requete(curseur, """insert into Aeroport (id, nom, coordonnees_nord, coordonnees_est) values ("HND", "Haneda", 35.552602, 139.779739)""")
    executer_requete(curseur, """insert into Aeroport (id, nom, coordonnees_nord, coordonnees_est) values ("SYD", "Kingsford Smith", -33.945549, 151.177197)""")
    executer_requete(curseur, """insert into Aeroport (id, nom, coordonnees_nord, coordonnees_est) values ("PVG", "Pudong", 31.143333, 121.805278)""")
    executer_requete(curseur, """insert into Aeroport (id, nom, coordonnees_nord, coordonnees_est) values ("IKA", "Imam Khomeini", 35.416107, 51.152236)""")
    executer_requete(curseur, """insert into Aeroport (id, nom, coordonnees_nord, coordonnees_est) values ("IST", "Ataturk", 40.976221, 28.814199)""")
    executer_requete(curseur, """insert into Aeroport (id, nom, coordonnees_nord, coordonnees_est) values ("CAI", "Aeroport international du Caire", 30.122153, 31.405621)""")
    executer_requete(curseur, """insert into Aeroport (id, nom, coordonnees_nord, coordonnees_est) values ("TXL", "Tegel", 52.560647, 13.28805)""")
    executer_requete(curseur, """insert into Aeroport (id, nom, coordonnees_nord, coordonnees_est) values ("RKV", "Reykjavikurflugvollur", 64.130383, -21.940298)""")
    executer_requete(curseur, """insert into Aeroport (id, nom, coordonnees_nord, coordonnees_est) values ("DEL", "Indira-Gandhi", 28.558328, 77.094111)""")
    executer_requete(curseur, """insert into Aeroport (id, nom, coordonnees_nord, coordonnees_est) values ("FCO", "Fumicino-Leibardo da Vinci", 41.807533, 12.250786)""")
    executer_requete(curseur, """insert into Aeroport (id, nom, coordonnees_nord, coordonnees_est) values ("SVO", "Cheremetievo", 55.966918, 37.41673)""")
    executer_requete(curseur, """insert into Aeroport (id, nom, coordonnees_nord, coordonnees_est) values ("OTP", "Henri Coanda", 44.571389, 26.103611)""")
    executer_requete(curseur, """insert into Aeroport (id, nom, coordonnees_nord, coordonnees_est) values ("PRG", "Vaclav-Havel", 50.101643, 14.26034)""")
    executer_requete(curseur, """insert into Aeroport (id, nom, coordonnees_nord, coordonnees_est) values ("SCL", "Arturo-Merino-Benitez", -33.391893, -70.785942)""")
    executer_requete(curseur, """insert into Aeroport (id, nom, coordonnees_nord, coordonnees_est) values ("TGU", "Toncontin", 14.060883, -87.217197)""")
    executer_requete(curseur, """insert into Aeroport (id, nom, coordonnees_nord, coordonnees_est) values ("HAV", "Jose Marti", 22.989167, -82.409167)""")
    executer_requete(curseur, """insert into Aeroport (id, nom, coordonnees_nord, coordonnees_est) values ("FIH", "Ndjili", -4.381671, 15.444546)""")
    executer_requete(curseur, """insert into Aeroport (id, nom, coordonnees_nord, coordonnees_est) values ("NDJ", "Aeroport international de Ndjamena", 12.133611, 15.033889)""")


    # Ajout des villes
    executer_requete(curseur, """insert into Ville (id, nom, pays, decalage_fuseau_horaire) values ("33PARIS", "Paris", "France", +1)""")
    executer_requete(curseur, """insert into Ville (id, nom, pays, decalage_fuseau_horaire) values ("34BARCELONE", "Barcelone", "Espagne", +1)""")
    executer_requete(curseur, """insert into Ville (id, nom, pays, decalage_fuseau_horaire) values ("31AMSTERDAM", "Amsterdam", "Pays-Bas", +1)""")
    executer_requete(curseur, """insert into Ville (id, nom, pays, decalage_fuseau_horaire) values ("44LONDRES", "Londres", "Royaume-Uni", +0)""")
    executer_requete(curseur, """insert into Ville (id, nom, pays, decalage_fuseau_horaire) values ("01NEWYORK", "New-York", "Etats-Unis", -5)""")
    executer_requete(curseur, """insert into Ville (id, nom, pays, decalage_fuseau_horaire) values ("33SAINTDENISDELAREUNION", "Saint-Denis de la Reunion", "France", +4)""")
    executer_requete(curseur, """insert into Ville (id, nom, pays, decalage_fuseau_horaire) values ("58CARACAS", "Caracas", "Venezuela", 10, -4,5)""")
    executer_requete(curseur, """insert into Ville (id, nom, pays, decalage_fuseau_horaire) values ("976OULANBATOR", "Oulan-Bator", "Mongolie", +8)""")
    executer_requete(curseur, """insert into Ville (id, nom, pays, decalage_fuseau_horaire) values ("64AUCKLAND", "Auckland", "Nouvelle-Zelande", +12)""")
    executer_requete(curseur, """insert into Ville (id, nom, pays, decalage_fuseau_horaire) values ("60KUALALUMPUR", "Kualu-Lumpur", "Malaisie", +8)""")
    executer_requete(curseur, """insert into Ville (id, nom, pays, decalage_fuseau_horaire) values ("237DOUALA", "Douala", "Cameroun", +1)""")
    executer_requete(curseur, """insert into Ville (id, nom, pays, decalage_fuseau_horaire) values ("255DODOMA", "Dodoma", "Tanzanie", +3)""")
    executer_requete(curseur, """insert into Ville (id, nom, pays, decalage_fuseau_horaire) values ("27JOHANNESBOURG", "Johannesbourg", "Afrique-du-Sud", +2)""")
    executer_requete(curseur, """insert into Ville (id, nom, pays, decalage_fuseau_horaire) values ("41GENEVE", "Geneve", "Suisse", +1)""")
    executer_requete(curseur, """insert into Ville (id, nom, pays, decalage_fuseau_horaire) values ("33TOULOUSE", "Toulouse", "France", +1)""")
    executer_requete(curseur, """insert into Ville (id, nom, pays, decalage_fuseau_horaire) values ("33LYON", "Lyon", "France", +1)""")
    executer_requete(curseur, """insert into Ville (id, nom, pays, decalage_fuseau_horaire) values ("55RIODEJANEIRO", "Rio de Janeiro", "Bresil", -3)""")
    executer_requete(curseur, """insert into Ville (id, nom, pays, decalage_fuseau_horaire) values ("54BUENOSAIRES", "Buenos Aires", "Argentine", -3)""")
    executer_requete(curseur, """insert into Ville (id, nom, pays, decalage_fuseau_horaire) values ("01MONTREAL", "Montreal", "Canada", -3)""")
    executer_requete(curseur, """insert into Ville (id, nom, pays, decalage_fuseau_horaire) values ("46STOCKHOLM", "Stockholm", "Suede", +1)""")
    executer_requete(curseur, """insert into Ville (id, nom, pays, decalage_fuseau_horaire) values ("972TELAVIV", "Tel-Aviv", "Israel", +1)""")
    executer_requete(curseur, """insert into Ville (id, nom, pays, decalage_fuseau_horaire) values ("81TOKYO", "Tokyo", "Japon", +9)""")
    executer_requete(curseur, """insert into Ville (id, nom, pays, decalage_fuseau_horaire) values ("61SYDNEY", "Sydney", "Australie", +10)""")
    executer_requete(curseur, """insert into Ville (id, nom, pays, decalage_fuseau_horaire) values ("86SHANGAI", "Shangai", "Chine", +8)""")
    executer_requete(curseur, """insert into Ville (id, nom, pays, decalage_fuseau_horaire) values ("98TEHERAN", "Teheran", "Iran", +3,5)""")
    executer_requete(curseur, """insert into Ville (id, nom, pays, decalage_fuseau_horaire) values ("90ISTANBUL", "Istanbul", "Turquie", +2)""")
    executer_requete(curseur, """insert into Ville (id, nom, pays, decalage_fuseau_horaire) values ("20LECAIRE", "Le Caire", "Egypte", +2)""")
    executer_requete(curseur, """insert into Ville (id, nom, pays, decalage_fuseau_horaire) values ("49ALLEMAGNE", "Berlin", "Allemagne", +1)""")
    executer_requete(curseur, """insert into Ville (id, nom, pays, decalage_fuseau_horaire) values ("354REYKJAVIK", "Reykjavik", "Islande", +0)""")
    executer_requete(curseur, """insert into Ville (id, nom, pays, decalage_fuseau_horaire) values ("91NEWDELHI", "New-Delhi", "Inde", +5,5)""")
    executer_requete(curseur, """insert into Ville (id, nom, pays, decalage_fuseau_horaire) values ("39ROME", "Rome", "Italie", +1)""")
    executer_requete(curseur, """insert into Ville (id, nom, pays, decalage_fuseau_horaire) values ("7MOSCOU", "Moscou", "Russie", +3)""")
    executer_requete(curseur, """insert into Ville (id, nom, pays, decalage_fuseau_horaire) values ("40BUCAREST", "Bucarest", "Roumanie", +2)""")
    executer_requete(curseur, """insert into Ville (id, nom, pays, decalage_fuseau_horaire) values ("420PRAGUE", "Prague", "Republique-Tcheque", +1)""")
    executer_requete(curseur, """insert into Ville (id, nom, pays, decalage_fuseau_horaire) values ("56SANTIAGODUCHILI", "Santiago du Chili", "Santiago", -4)""")
    executer_requete(curseur, """insert into Ville (id, nom, pays, decalage_fuseau_horaire) values ("504TEGUCIGALPA", "Tegucigalpa", "Honduras", -6)""")
    executer_requete(curseur, """insert into Ville (id, nom, pays, decalage_fuseau_horaire) values ("53LAHAVANE", "La Havane", "Cuba", -5)""")
    executer_requete(curseur, """insert into Ville (id, nom, pays, decalage_fuseau_horaire) values ("243KINSHASA", "Kinshasa", "Republique democratique du Congo", +1)""")
    executer_requete(curseur, """insert into Ville (id, nom, pays, decalage_fuseau_horaire) values ("235NDJAMENA", "Ndjamena", "Tchad", +1)""")

    
    
    # Ajout des compagnies
    executer_requete(curseur, """insert into Compagnie (id, nom) values (1, "Lippoutou", 100, "Eleve")""")


    # Ajout des avions
    executer_requete(curseur, """insert into Avion (id, capacite_maximale, autonomie_maximale) values (, "Ecras'face")""")
    executer_requete(curseur, """insert into Avion (id, capacite_maximale, autonomie_maximale) values (1, "Léchouille")""")
    executer_requete(curseur, """insert into Avion (id, capacite_maximale, autonomie_maximale) values (1, "Blizzard")""")
    executer_requete(curseur, """insert into Avion (id, capacite_maximale, autonomie_maximale) values (1, "Torgnoles")""")
    executer_requete(curseur, """insert into Avion (id, capacite_maximale, autonomie_maximale) values (2, "Coup d'jus")""")


    # Ajout des vols
    executer_requete(curseur, """insert into Vol (numero_de_vol, id_aeroport_depart, id_aeroport_arrivee, date_depart) values ("1", "CDG", "AMS", "07 Apr 16 08:30")""")
    executer_requete(curseur, """insert into Vol (numero_de_vol, id_aeroport_depart, id_aeroport_arrivee, date_depart) values ("2", "AMS", "JFK", "07 Apr 16 15:42")""")
    executer_requete(curseur, """insert into Vol (numero_de_vol, id_aeroport_depart, id_aeroport_arrivee, date_depart) values ("3", "LGT", "BCN", "07 Apr 16 09:10")""")
    executer_requete(curseur, """insert into Vol (numero_de_vol, id_aeroport_depart, id_aeroport_arrivee, date_depart) values ("4", "")""")
    executer_requete(curseur, """insert into Vol (numero_de_vol, id_aeroport_depart, id_aeroport_arrivee, date_depart) values ("1", "Ecras'face")""")
 

   # Ajout des passagers
    executer_requete(curseur, """insert into Passager (id_reservation, adresse_mail, nom, prenom) values ("1", "CDG", "AMS", , 8.5)""")
    executer_requete(curseur, """insert into Passager (id_reservation, adresse_mail, nom, prenom) values ("2", "AMS", "JFK", ,15.25)""")
    executer_requete(curseur, """insert into Passager (id_reservation, adresse_mail, nom, prenom) values ("3", "Ecras'face")""")
    executer_requete(curseur, """insert into Passager (id_reservation, adresse_mail, nom, prenom) values ("4", "Ecras'face")""")
    executer_requete(curseur, """insert into Passager (id_reservation, adresse_mail, nom, prenom) values ("1", "Ecras'face")""")


    #On valide les modifications
    valider_modif(base)
    #on ferme la bdd
    fermer_db(base,surseur)


